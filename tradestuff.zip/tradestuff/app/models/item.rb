class Item < ActiveRecord::Base
  attr_accessor :item_id, :item_name, :item_desc
  
end
