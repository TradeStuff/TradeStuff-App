Given("I am on the homepage") do
  pending # Write code here that turns the phrase above into concrete actions
end

When("I follow {string}") do |string|
  pending # Write code here that turns the phrase above into concrete actions
end

When("I {string} sign in with email and pass") do |string|
  pending # Write code here that turns the phrase above into concrete actions
end

Then("I should see {string}") do |string|
  pending # Write code here that turns the phrase above into concrete actions
end

Given("I follow {string}") do |string|
  pending # Write code here that turns the phrase above into concrete actions
end